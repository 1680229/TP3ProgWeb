export class Comment{
    constructor(
        public id : number,
        public text : string,
        public upvotes : number,
        public downvotes : number
    ){}
}