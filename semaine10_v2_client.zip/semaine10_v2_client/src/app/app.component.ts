import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { lastValueFrom } from 'rxjs';
import { Comment } from './models/comment';
import { LoginDTO } from './models/loginDTO';
import { RegisterDTO } from './models/registerDTO';

const domain = "https://localhost:7182/"

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  // Register inputs
  registerUsername : string = "";
  registerEmail : string = "";
  registerPassword : string = "";
  registerPasswordConfirm : string = "";

  // Login inputs
  loginUsername : string = "";
  loginPassword : string = "";

  // Comment list
  comments : Comment[] = [];

  // Input comment
  commentText : string = "";

  constructor(public http : HttpClient){}

  async register() : Promise<void> {

    let registerDTO = {
      username : this.registerUsername, 
      email : this.registerEmail, 
      password : this.registerPassword, 
      passwordConfirm : this.registerPasswordConfirm};
    
    let x = await lastValueFrom(this.http.post<any>(domain + "api/Users/Register", registerDTO));
    console.log(x);
  }

  async login() : Promise<void>{
    let loginDTO =  new LoginDTO(this.loginUsername, this.loginPassword);
    let x = await lastValueFrom(this.http.post<any>(domain + "api/Users/Login", loginDTO));
    console.log(x);
    localStorage.setItem("token", x.token);
  }

  async getComments() : Promise<void>{
    let x = await lastValueFrom(this.http.get<Comment[]>(domain + "api/Comments/GetComment"));
    console.log(x);
    this.comments = x;
  }

  async getMyComments() : Promise<void>{
    let x = await lastValueFrom(this.http.get<Comment[]>(domain + "api/Comments/GetMyComments"));
    console.log(x);
    this.comments = x;
  }

  async postComment() : Promise<void>{
    let newComment = new Comment(0, this.commentText, 0, 0);

    let x = await lastValueFrom(this.http.post<Comment>(domain + "api/Comments/PostComment", newComment));
    console.log(x);

    this.commentText = "";
  }

  logout(){
    localStorage.removeItem("token");
  }

}
